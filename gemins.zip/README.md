
  # Plataforma de Tutorías Universitarias

  This is a code bundle for Plataforma de Tutorías Universitarias. The original project is available at https://www.figma.com/design/XMvcnxRCkDO0wq9BDoNWJw/Plataforma-de-Tutor%C3%ADas-Universitarias.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  