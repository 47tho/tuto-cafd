import React, { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "./utils/auth-context";
import { apiRequest } from "./utils/api";
import { LandingPage } from "./components/LandingPage";
import { Navbar } from "./components/Navbar";
import { StudentDashboard } from "./components/StudentDashboard";
import { TutorSearch } from "./components/TutorSearch";
import { TutorProfile } from "./components/TutorProfile";
import { MyRequests } from "./components/MyRequests";
import { TutorInbox } from "./components/TutorInbox";
import { AvailabilityManagement } from "./components/AvailabilityManagement";
import { Profile } from "./components/Profile";
import { Notifications } from "./components/Notifications";
import { AdminDashboard } from "./components/AdminDashboard";
import { AdminTutorApplications } from "./components/AdminTutorApplications";
import { AdminReviews } from "./components/AdminReviews";
import { AdminUsers } from "./components/AdminUsers";
import { AdminUserDetail } from "./components/AdminUserDetail";
import { Toaster } from "./components/ui/sonner";

function AppContent() {
  const { user, loading: authLoading, accessToken } = useAuth();
  const [currentView, setCurrentView] = useState("dashboard");
  const [viewData, setViewData] = useState<any>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [actingAsStudent, setActingAsStudent] = useState(false);

  useEffect(() => {
    if (user && accessToken) {
      loadNotificationCount();
      // Poll for new notifications every 30 seconds
      const interval = setInterval(
        loadNotificationCount,
        30000,
      );
      return () => clearInterval(interval);
    }
  }, [user, accessToken]);

  const loadNotificationCount = async () => {
    try {
      const data = await apiRequest(
        "/notifications",
        {},
        accessToken,
      );
      const unread = data.notifications.filter(
        (n: any) => !n.read,
      ).length;
      setNotificationCount(unread);
    } catch (error) {
      console.error("Error loading notification count:", error);
    }
  };

  const navigate = (view: string, data?: any) => {
    setCurrentView(view);
    setViewData(data);
    window.scrollTo(0, 0);
  };

  // Show loading state
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Cargando...</p>
        </div>
      </div>
    );
  }

  // Show landing page if not authenticated
  if (!user) {
    return <LandingPage />;
  }

  // Determine effective role (for tutors acting as students)
  const effectiveRole =
    user.role === "tutor" && actingAsStudent
      ? "student"
      : user.role;

  // Check if tutor is not approved yet
  if (
    user.role === "tutor" &&
    !user.approved &&
    !actingAsStudent
  ) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar
          onNavigate={navigate}
          currentView={currentView}
          notificationCount={notificationCount}
        />
        <div className="max-w-2xl mx-auto px-4 py-20 text-center">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-8">
            <h2 className="mb-4">
              Solicitud Pendiente de Aprobación
            </h2>
            <p className="text-muted-foreground mb-6">
              Tu solicitud para ser tutor está siendo revisada
              por un administrador. Te notificaremos cuando sea
              aprobada.
            </p>
            <p className="text-sm text-muted-foreground">
              Mientras tanto, puedes explorar la plataforma como
              estudiante.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Handle "act as student" view switching for tutors
  if (
    currentView === "act-as-student" &&
    user.role === "tutor"
  ) {
    setActingAsStudent(true);
    setCurrentView("dashboard");
    return null;
  }

  // Render appropriate view based on role and current view
  const renderView = () => {
    // Student views
    if (effectiveRole === "student") {
      switch (currentView) {
        case "dashboard":
          return <StudentDashboard onNavigate={navigate} />;
        case "search":
          return (
            <TutorSearch
              onNavigate={navigate}
              initialQuery={viewData?.query}
            />
          );
        case "tutor-profile":
          return (
            <TutorProfile
              tutorId={viewData?.tutorId}
              onNavigate={navigate}
            />
          );
        case "my-requests":
          return <MyRequests onNavigate={navigate} />;
        case "profile":
          return <Profile />;
        case "notifications":
          return <Notifications />;
        default:
          return <StudentDashboard onNavigate={navigate} />;
      }
    }

    // Tutor views
    if (user.role === "tutor") {
      switch (currentView) {
        case "dashboard":
        case "requests-inbox":
          return <TutorInbox />;
        case "my-tutorias":
          return <MyRequests onNavigate={navigate} />;
        case "availability":
          return <AvailabilityManagement />;
        case "profile":
          return <Profile />;
        case "notifications":
          return <Notifications />;
        default:
          return <TutorInbox />;
      }
    }

    // Admin views
    if (user.role === "admin") {
      switch (currentView) {
        case "dashboard":
          return <AdminDashboard onNavigate={navigate} />;
        case "admin-tutors":
          return <AdminTutorApplications />;
        case "admin-reviews":
          return <AdminReviews />;
        case "admin-users":
          return <AdminUsers onNavigate={navigate} />;
        case "admin-user-detail":
          return (
            <AdminUserDetail
              userId={viewData?.userId}
              userRole={viewData?.userRole}
              onNavigate={navigate}
            />
          );
        case "profile":
          return <Profile />;
        case "notifications":
          return <Notifications />;
        default:
          return <AdminDashboard onNavigate={navigate} />;
      }
    }

    return <StudentDashboard onNavigate={navigate} />;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        onNavigate={navigate}
        currentView={currentView}
        notificationCount={notificationCount}
      />
      <main>{renderView()}</main>
      <Footer />
    </div>
  );
}

// Footer component
function Footer() {
  return (
    <footer className="bg-muted/50 py-8 px-4 mt-20">
      <div className="max-w-7xl mx-auto text-center text-muted-foreground">
        <div className="flex justify-center gap-6 mb-4 text-sm">
          <a href="#" className="hover:text-primary">
            Sobre Nosotros
          </a>
          <a href="#" className="hover:text-primary">
            Contacto
          </a>
          <a href="#" className="hover:text-primary">
            Términos y Condiciones
          </a>
          <a href="#" className="hover:text-primary">
            Política de Privacidad
          </a>
        </div>
        <p className="text-sm">
          &copy; 2025 TUTO-CAFD. Todos los derechos reservados.
        </p>
      </div>
    </footer>
  );
}

// Main App wrapper with AuthProvider
export default function App() {
  return (
    <AuthProvider>
      <AppContent />
      <Toaster />
    </AuthProvider>
  );
}