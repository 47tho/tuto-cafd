import React, { useState } from "react";
import {
  BookOpen,
  Search,
  Users,
  Star,
  CheckCircle,
} from "lucide-react";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import { Textarea } from "./ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { useAuth } from "../utils/auth-context";
import { SUBJECTS, CAREERS } from "../utils/constants";

export function LandingPage() {
  const { signIn, signUp } = useAuth();
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [selectedSubjects, setSelectedSubjects] = useState<
    string[]
  >([]);
  const [selectedCareer, setSelectedCareer] =
    useState<string>("");

  const handleSignIn = async (
    e: React.FormEvent<HTMLFormElement>,
  ) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;

    try {
      await signIn(email, password);
      setShowAuthDialog(false);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (
    e: React.FormEvent<HTMLFormElement>,
    role: string,
  ) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const data: any = {
      email: formData.get("email") as string,
      password: formData.get("password") as string,
      name: formData.get("name") as string,
      role,
    };

    if (role === "student") {
      data.carrera =
        selectedCareer || (formData.get("carrera") as string);
    } else if (role === "tutor") {
      data.bio = formData.get("bio") as string;
      data.subjects = selectedSubjects;
    }

    try {
      await signUp(data);
      if (role === "tutor") {
        setSuccess(
          "Tu solicitud ha sido enviada. Un administrador la revisará pronto.",
        );
        setTimeout(() => setShowAuthDialog(false), 3000);
      } else {
        setShowAuthDialog(false);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="text-xl font-semibold text-primary">
                TUTO-CAFD
              </span>
            </div>
            <div className="flex gap-3">
              <Button
                variant="ghost"
                onClick={() => setShowAuthDialog(true)}
              >
                Iniciar Sesión
              </Button>
              <Button onClick={() => setShowAuthDialog(true)}>
                Registrarse
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Conecta con el conocimiento.
            <br />
            Encuentra tu tutor ideal.
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            TUTO-CAFD te ayuda a encontrar tutores
            universitarios expertos para tus materias más
            desafiantes. Aprende de los mejores, a tu ritmo.
          </p>
          <Button
            size="lg"
            onClick={() => setShowAuthDialog(true)}
            className="gap-2"
          >
            <Search className="h-5 w-5" />
            Registrarse Ahora
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-semibold text-center mb-12">
            ¿Cómo Funciona?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2">Busca tu Materia</h3>
              <p className="text-gray-600">
                Encuentra tutores especializados en la materia
                que necesitas.
              </p>
            </div>
            <div className="text-center p-6">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2">Conecta con Tutores</h3>
              <p className="text-gray-600">
                Revisa perfiles, calificaciones y envía
                solicitudes de tutoría.
              </p>
            </div>
            <div className="text-center p-6">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2">Aprende y Crece</h3>
              <p className="text-gray-600">
                Recibe tutorías de calidad y mejora tu
                rendimiento académico.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 py-8 px-4">
        <div className="max-w-7xl mx-auto text-center text-gray-600">
          <div className="flex justify-center gap-6 mb-4">
            <a href="#" className="hover:text-primary">
              Sobre Nosotros
            </a>
            <a href="#" className="hover:text-primary">
              Contacto
            </a>
            <a href="#" className="hover:text-primary">
              Términos y Condiciones
            </a>
            <a href="#" className="hover:text-primary">
              Política de Privacidad
            </a>
          </div>
          <p>
            &copy; 2025 TUTO-CAFD. Todos los derechos
            reservados.
          </p>
        </div>
      </footer>

      {/* Auth Dialog */}
      <Dialog
        open={showAuthDialog}
        onOpenChange={(open) => {
          setShowAuthDialog(open);
          if (!open) {
            setSelectedSubjects([]);
            setSelectedCareer("");
            setError("");
            setSuccess("");
          }
        }}
      >
        <DialogContent
          className="sm:max-w-[500px] !flex !flex-col !p-0 !gap-0"
          style={{
            maxHeight: "90vh",
            height: "auto",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          <DialogHeader className="px-6 pt-6 pb-4 flex-shrink-0 border-b">
            <DialogTitle>Accede a TUTO-CAFD</DialogTitle>
            <DialogDescription>
              Inicia sesión o regístrate para comenzar
            </DialogDescription>
          </DialogHeader>

          <div
            className="flex-1 overflow-y-auto px-6 pb-6"
            style={{
              minHeight: 0,
              maxHeight: "calc(90vh - 140px)",
              overflowY: "auto",
            }}
          >
            <Tabs
              defaultValue="signin"
              className="w-full"
              onValueChange={() => {
                setSelectedSubjects([]);
                setSelectedCareer("");
                setError("");
                setSuccess("");
              }}
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin">
                  Iniciar Sesión
                </TabsTrigger>
                <TabsTrigger value="signup">
                  Registrarse
                </TabsTrigger>
              </TabsList>

              <TabsContent value="signin">
                <form
                  onSubmit={handleSignIn}
                  className="space-y-4"
                >
                  <div>
                    <Label htmlFor="signin-email">
                      Correo Electrónico
                    </Label>
                    <Input
                      id="signin-email"
                      name="email"
                      type="email"
                      required
                      placeholder="tu@email.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="signin-password">
                      Contraseña
                    </Label>
                    <Input
                      id="signin-password"
                      name="password"
                      type="password"
                      required
                      placeholder="••••••••"
                    />
                  </div>
                  {error && (
                    <div className="text-destructive text-sm">
                      {error}
                    </div>
                  )}
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={loading}
                  >
                    {loading
                      ? "Iniciando sesión..."
                      : "Iniciar Sesión"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <Tabs defaultValue="student" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-4">
                    <TabsTrigger value="student">
                      Estudiante
                    </TabsTrigger>
                    <TabsTrigger value="tutor">
                      Tutor
                    </TabsTrigger>
                    <TabsTrigger value="admin">
                      Admin
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="student">
                    <form
                      onSubmit={(e) =>
                        handleSignUp(e, "student")
                      }
                      className="space-y-4"
                    >
                      <div>
                        <Label htmlFor="student-name">
                          Nombre Completo
                        </Label>
                        <Input
                          id="student-name"
                          name="name"
                          required
                          placeholder="Juan Pérez"
                        />
                      </div>
                      <div>
                        <Label htmlFor="student-email">
                          Correo Electrónico
                        </Label>
                        <Input
                          id="student-email"
                          name="email"
                          type="email"
                          required
                          placeholder="tu@email.com"
                        />
                      </div>
                      <div>
                        <Label htmlFor="student-password">
                          Contraseña
                        </Label>
                        <Input
                          id="student-password"
                          name="password"
                          type="password"
                          required
                          placeholder="••••••••"
                          minLength={6}
                        />
                      </div>
                      <div>
                        <Label htmlFor="student-carrera">
                          Carrera
                        </Label>
                        <Select
                          value={selectedCareer}
                          onValueChange={setSelectedCareer}
                          required
                        >
                          <SelectTrigger id="student-carrera">
                            <SelectValue placeholder="Selecciona tu carrera" />
                          </SelectTrigger>
                          <SelectContent>
                            {CAREERS.map((career) => (
                              <SelectItem
                                key={career}
                                value={career}
                              >
                                {career}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {error && (
                        <div className="text-destructive text-sm">
                          {error}
                        </div>
                      )}
                      {success && (
                        <div className="text-green-600 text-sm flex items-center gap-2">
                          <CheckCircle className="h-4 w-4" />
                          {success}
                        </div>
                      )}
                      <Button
                        type="submit"
                        className="w-full"
                        disabled={loading || !selectedCareer}
                      >
                        {loading
                          ? "Registrando..."
                          : "Crear Cuenta de Estudiante"}
                      </Button>
                    </form>
                  </TabsContent>

                  <TabsContent value="tutor">
                    <form
                      onSubmit={(e) => handleSignUp(e, "tutor")}
                      className="space-y-4"
                    >
                      <div>
                        <Label htmlFor="tutor-name">
                          Nombre Completo
                        </Label>
                        <Input
                          id="tutor-name"
                          name="name"
                          required
                          placeholder="María García"
                        />
                      </div>
                      <div>
                        <Label htmlFor="tutor-email">
                          Correo Electrónico
                        </Label>
                        <Input
                          id="tutor-email"
                          name="email"
                          type="email"
                          required
                          placeholder="tu@email.com"
                        />
                      </div>
                      <div>
                        <Label htmlFor="tutor-password">
                          Contraseña
                        </Label>
                        <Input
                          id="tutor-password"
                          name="password"
                          type="password"
                          required
                          placeholder="••••••••"
                          minLength={6}
                        />
                      </div>
                      <div>
                        <Label htmlFor="tutor-bio">
                          Biografía
                        </Label>
                        <Textarea
                          id="tutor-bio"
                          name="bio"
                          required
                          placeholder="Cuéntanos sobre tu experiencia..."
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label>
                          Materias que puedes enseñar
                        </Label>
                        <div
                          className="mt-2 border rounded-md p-3"
                          style={{
                            maxHeight: "200px",
                            overflowY: "auto",
                            overflowX: "hidden",
                          }}
                        >
                          <div className="flex flex-wrap gap-2">
                            {SUBJECTS.map((subject) => (
                              <button
                                key={subject}
                                type="button"
                                onClick={() => {
                                  setSelectedSubjects((prev) =>
                                    prev.includes(subject)
                                      ? prev.filter(
                                          (s) => s !== subject,
                                        )
                                      : [...prev, subject],
                                  );
                                }}
                                className={`px-3 py-1.5 text-sm rounded-md border transition-colors ${
                                  selectedSubjects.includes(
                                    subject,
                                  )
                                    ? "bg-primary text-primary-foreground border-primary"
                                    : "bg-background hover:bg-accent border-border"
                                }`}
                              >
                                {subject}
                              </button>
                            ))}
                          </div>
                        </div>
                        {selectedSubjects.length === 0 && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Selecciona al menos una materia
                          </p>
                        )}
                        {selectedSubjects.length > 0 && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {selectedSubjects.length} materia(s)
                            seleccionada(s)
                          </p>
                        )}
                      </div>
                      {error && (
                        <div className="text-destructive text-sm">
                          {error}
                        </div>
                      )}
                      {success && (
                        <div className="text-green-600 text-sm flex items-center gap-2">
                          <CheckCircle className="h-4 w-4" />
                          {success}
                        </div>
                      )}
                      <Button
                        type="submit"
                        className="w-full"
                        disabled={
                          loading ||
                          selectedSubjects.length === 0
                        }
                      >
                        {loading
                          ? "Enviando solicitud..."
                          : "Enviar Solicitud"}
                      </Button>
                      <p className="text-xs text-muted-foreground text-center">
                        Tu solicitud será revisada por un
                        administrador
                      </p>
                    </form>
                  </TabsContent>

                  <TabsContent value="admin">
                    <form
                      onSubmit={(e) => handleSignUp(e, "admin")}
                      className="space-y-4"
                    >
                      <div>
                        <Label htmlFor="admin-name">
                          Nombre Completo
                        </Label>
                        <Input
                          id="admin-name"
                          name="name"
                          required
                          placeholder="Admin Sistema"
                        />
                      </div>
                      <div>
                        <Label htmlFor="admin-email">
                          Correo Electrónico
                        </Label>
                        <Input
                          id="admin-email"
                          name="email"
                          type="email"
                          required
                          placeholder="admin@tuto-cafd.com"
                        />
                      </div>
                      <div>
                        <Label htmlFor="admin-password">
                          Contraseña
                        </Label>
                        <Input
                          id="admin-password"
                          name="password"
                          type="password"
                          required
                          placeholder="••••••••"
                          minLength={6}
                        />
                      </div>
                      {error && (
                        <div className="text-destructive text-sm">
                          {error}
                        </div>
                      )}
                      {success && (
                        <div className="text-green-600 text-sm flex items-center gap-2">
                          <CheckCircle className="h-4 w-4" />
                          {success}
                        </div>
                      )}
                      <Button
                        type="submit"
                        className="w-full"
                        disabled={loading}
                      >
                        {loading
                          ? "Registrando..."
                          : "Crear Cuenta de Administrador"}
                      </Button>
                      <p className="text-xs text-muted-foreground text-center">
                        Solo para personal autorizado
                      </p>
                    </form>
                  </TabsContent>
                </Tabs>
              </TabsContent>
            </Tabs>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}