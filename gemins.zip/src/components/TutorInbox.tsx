import React, { useState, useEffect } from 'react';
import { Inbox, CheckCircle, XCircle, Clock } from 'lucide-react';
import { useAuth } from '../utils/auth-context';
import { apiRequest } from '../utils/api';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';

interface Request {
  id: string;
  studentId: string;
  studentName: string;
  subject: string;
  date: string;
  time: string;
  message: string;
  status: string;
  createdAt: string;
}

export function TutorInbox() {
  const { accessToken } = useAuth();
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    try {
      setLoading(true);
      const data = await apiRequest('/requests', {}, accessToken);
      // Only show pending requests in inbox
      setRequests(data.requests.filter((r: Request) => r.status === 'pending'));
    } catch (error) {
      console.error('Error loading requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (requestId: string) => {
    try {
      await apiRequest(
        `/requests/${requestId}`,
        {
          method: 'PUT',
          body: JSON.stringify({ status: 'accepted' }),
        },
        accessToken
      );
      loadRequests();
    } catch (error) {
      console.error('Error accepting request:', error);
    }
  };

  const handleReject = async (requestId: string) => {
    if (!confirm('¿Estás seguro de que quieres rechazar esta solicitud?')) return;

    try {
      await apiRequest(
        `/requests/${requestId}`,
        {
          method: 'PUT',
          body: JSON.stringify({ status: 'rejected' }),
        },
        accessToken
      );
      loadRequests();
    } catch (error) {
      console.error('Error rejecting request:', error);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="mb-2">Buzón de Solicitudes</h1>
        <p className="text-muted-foreground">
          Revisa y gestiona las solicitudes de tutoría
        </p>
      </div>

      {loading ? (
        <p className="text-center text-muted-foreground">Cargando solicitudes...</p>
      ) : requests.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Inbox className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              No tienes solicitudes pendientes
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {requests.map((request, idx) => (
            <Card key={request.id}>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  {/* Student Avatar */}
                  <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center flex-shrink-0">
                    {request.studentName.charAt(0).toUpperCase()}
                  </div>

                  {/* Request Details */}
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="mb-1">{request.studentName}</h3>
                        <p className="text-sm text-muted-foreground">
                          Materia: {request.subject}
                        </p>
                      </div>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Pendiente
                      </Badge>
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="text-sm">
                        <span className="font-medium">Fecha y hora propuesta:</span>{' '}
                        <span className="text-muted-foreground">
                          {request.date} - {request.time}
                        </span>
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">Mensaje del estudiante:</span>
                        <p className="text-muted-foreground mt-1 bg-accent/50 p-3 rounded-lg">
                          {request.message}
                        </p>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Recibida: {new Date(request.createdAt).toLocaleString('es-ES', {
                          dateStyle: 'short',
                          timeStyle: 'short'
                        })}
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleAccept(request.id)}
                        className="gap-2"
                      >
                        <CheckCircle className="h-4 w-4" />
                        Aceptar
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleReject(request.id)}
                        className="gap-2 text-destructive hover:text-destructive"
                      >
                        <XCircle className="h-4 w-4" />
                        Rechazar
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
